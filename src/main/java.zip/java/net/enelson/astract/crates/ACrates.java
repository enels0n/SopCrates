package net.enelson.astract.crates;

import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import com.google.common.reflect.ClassPath;

import net.kyori.adventure.platform.bukkit.BukkitAudiences;
import net.enelson.astract.crates.api.Placeholder;
import net.enelson.astract.crates.commands.CommandManager;
import net.enelson.astract.crates.crates.CratesManager;

public class ACrates extends JavaPlugin {
	public static ACrates plugin;
	private CratesManager manager;
	private BukkitAudiences adventure;

	public void onEnable() {

		plugin = this;
		this.getCommand("acrates").setExecutor(new CommandManager());
		manager = new CratesManager();

		PluginManager pluginManager = Bukkit.getPluginManager();
		try {
			String pac = "net.enelson.astract.crates.listeners";
			for (ClassPath.ClassInfo clazzInfo : ClassPath.from(getClassLoader()).getTopLevelClasses(pac)) {
				Class<?> clazz = Class.forName(clazzInfo.getName());
				if (Listener.class.isAssignableFrom(clazz)) {
					pluginManager.registerEvents((Listener) clazz.getDeclaredConstructor().newInstance(), this);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
			new Placeholder().register();
		}
		
		try {
			adventure = BukkitAudiences.create(this);
		}
		catch(NoSuchMethodError ex) {
			adventure = null;
		}
	}

	public BukkitAudiences getAdventure() {
		if (adventure == null) {
			throw new IllegalStateException("Tried to access Adventure when the plugin was disabled!");
		}
		return adventure;
	}

	public void onDisable() {
		manager.onDisable();
		if (adventure != null) {
			adventure.close();
			adventure = null;
		}
	}
	
	public static ACrates getInstance() {
		return plugin;
	}
	
	public CratesManager getCratesManager() {
		return manager;
	}
}
