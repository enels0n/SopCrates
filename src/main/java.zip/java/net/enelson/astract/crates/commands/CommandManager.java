package net.enelson.astract.crates.commands;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

//import com.iridium.iridiumcolorapi.IridiumColorAPI;

import net.enelson.astract.crates.ACrates;
import net.enelson.astract.crates.crates.CrateBlock;
import net.enelson.astract.crates.utils.Utils;
import net.md_5.bungee.api.ChatColor;

public class CommandManager implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		if(!sender.isOp())
			return false;
		
		if(args.length == 2 && args[0].equals("chances")) { //acrates chances example
			YamlConfiguration crateConfig = ACrates.getInstance().getCratesManager().getCrateConfig(args[1]);
			if(crateConfig == null) {
				sender.sendMessage("Неизвестный тип кейсов.");
				return false;
			}

			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "Шансы призов кейса &a&n" + crateConfig.getString("displayName")));
			//sender.sendMessage(IridiumColorAPI.process("Шансы призов кейса &a&n" + crateConfig.getString("displayName")));

			int totalWeight = 0;
			for (String id : crateConfig.getConfigurationSection("prizes").getKeys(false)) {
				totalWeight = totalWeight + crateConfig.getInt("prizes." + id + ".weight");
			}
			
			for (String id : crateConfig.getConfigurationSection("prizes").getKeys(false)) {
				Double chance = crateConfig.getDouble("prizes." + id + ".weight")/totalWeight;
				chance = (double) Math.round(chance * 10000.0) / 100;
				sender.sendMessage(ChatColor.translateAlternateColorCodes('&', id + ": " + crateConfig.getString("prizes."+id+".display.name") + " &a" + chance + "&f%"));
				//sender.sendMessage(IridiumColorAPI.process(id + ": " + crateConfig.getString("prizes."+id+".display.name") + " &a" + chance + "&f%"));
			}
			return false;
		}
		
		if((args.length == 4 || args.length == 5)&& args[0].equals("give")) { //acrates give <player> <crateName> <amount> [virtual]
			Player player = Bukkit.getPlayerExact(args[1]);
			if(player == null) {
				sender.sendMessage("Игрок не найден");
				return false;
			}
			
			if(args.length == 5 && args[4].equals("virtual")) {
				ACrates.getInstance().getCratesManager().addKey(player.getName(), args[2], Integer.parseInt(args[3]));
				return false;
			}
			
			ItemStack item = ACrates.getInstance().getCratesManager().generateKey(args[2], Integer.parseInt(args[3]));
			if(player.getInventory().addItem(item).size() != 0) {
				player.getWorld().dropItem(player.getLocation(), item);
			}
			return false;
		}
		
		if(args.length == 2 && args[0].equals("create")) { //acrates create <crateName>
			if(!(sender instanceof Player)) {
				sender.sendMessage("Only by player");
				return false;
			}
			
			Player player = (Player)sender;
			String direction = Utils.getCardinalDirection(player);
			Block block = player.getTargetBlockExact(5);
			if(block != null && !block.getType().equals(Material.AIR)) {
				if(!ACrates.getInstance().getCratesManager().createCrateBlock(block, direction, args[1])) {
					sender.sendMessage("Что-то пошло не так. Убедитесь в правильности написания названия кейса.");
				}
			}
			return false;
		}
		
		if(args.length > 0 && args[0].equals("remove")) { //acrates remove
			if(!(sender instanceof Player)) {
				sender.sendMessage("Only by player");
				return false;
			}
			
			Player player = (Player)sender;
			Block block = player.getTargetBlockExact(5);
			CrateBlock crateBlock = ACrates.getInstance().getCratesManager().getCrateBlock(block);
			if(crateBlock == null) {
				sender.sendMessage("Targeted block is not a crate");
				return false;
			}
			
			ACrates.getInstance().getCratesManager().removeCrateBlock(crateBlock);
			return false;
		}
		
		if(args.length > 0 && args[0].equals("reload")) { //acrates reload
			ACrates.getInstance().getCratesManager().reload();
			sender.sendMessage("The plugin has been reloaded.");
			return false;
		}
		sender.sendMessage("/acrates chances <crateName>");
		sender.sendMessage("/acrates give <player> <crateName> <amount> [virtual]");
		sender.sendMessage("/acrates create <crateName>");
		sender.sendMessage("/acrates remove");
		sender.sendMessage("/acrates reload");
		
		return false;
	}

}
