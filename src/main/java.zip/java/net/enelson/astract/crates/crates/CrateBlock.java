package net.enelson.astract.crates.crates;

import org.bukkit.Location;

public class CrateBlock {
	private Location location;
	private String crateName;
	private String direction;
	
	CrateBlock(Location location, String crateName, String direction) {
		this.location = location;
		this.crateName = crateName;
		this.direction = direction;
	}

	public Location getLocation() {
		return this.location.clone();
	}
	public String getCrateName() {
		return this.crateName;
	}
	public String getDirection() {
		return this.direction;
	}
}
