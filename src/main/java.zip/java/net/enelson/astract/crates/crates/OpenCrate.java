package net.enelson.astract.crates.crates;

import net.enelson.astract.crates.ACrates;
import net.enelson.astract.crates.utils.Utils;
import org.bukkit.*;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.EulerAngle;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class OpenCrate {

    private final CrateBlock crateBlock;
    private final Player player;

    private final List<ArmorStand> stands = new ArrayList<>(5);
    private final List<OpenPrize> timeline = new ArrayList<>();

    private BukkitTask task;

    private boolean finished = false;
    private boolean rewardGiven = false;

    private int tick = 0;
    private int nextShiftTick = 0;
    private int currentDelay = 1;

    private int centerIndex = 2;
    private int shiftsDone = 0;
    private int totalShifts = 0;

    private OpenPrize finalPrize;

    public OpenCrate(CrateBlock crateBlock, Player player) {
        this.crateBlock = crateBlock;
        this.player = player;
    }

    public void open() {
        if (finished) {
            return;
        }

        final String crateName = crateBlock.getCrateName();
        final YamlConfiguration crateConfig = ACrates.getInstance().getCratesManager().getCrateConfig(crateName);

        if (crateConfig == null) {
            player.sendMessage(ChatColor.RED + "Не удалось загрузить конфиг кейса.");
            forceStop();
            return;
        }

        final ConfigurationSection prizesSection = crateConfig.getConfigurationSection("prizes");
        if (prizesSection == null || prizesSection.getKeys(false).isEmpty()) {
            player.sendMessage(ChatColor.RED + "В кейсе нет призов.");
            forceStop();
            return;
        }

        this.finalPrize = rollPrize(crateName, crateConfig);
        buildTimeline(crateName, crateConfig, finalPrize);
        spawnArmorStands();
        updateVisibleItems(true);

        this.task = new BukkitRunnable() {
            @Override
            public void run() {
                if (finished) {
                    cancel();
                    return;
                }

                if (!player.isOnline()) {
                    forceStop();
                    cancel();
                    return;
                }

                tick++;

                if (tick < nextShiftTick) {
                    spinIdleEffect();
                    return;
                }

                if (shiftsDone >= totalShifts) {
                    finishOpening();
                    cancel();
                    return;
                }

                centerIndex++;
                shiftsDone++;

                updateVisibleItems(false);
                playSpinTickSound();

                currentDelay = calculateDelay(shiftsDone, totalShifts);
                nextShiftTick = tick + currentDelay;

                spinIdleEffect();
            }
        }.runTaskTimer(ACrates.getInstance(), 0L, 1L);
    }

    private void buildTimeline(String crateName, YamlConfiguration crateConfig, OpenPrize finalPrize) {
        timeline.clear();

        // Начальная "быстрая" часть
        for (int i = 0; i < 18; i++) {
            timeline.add(randomVisualPrize(crateName, crateConfig));
        }

        // Средняя часть
        for (int i = 0; i < 10; i++) {
            timeline.add(randomVisualPrize(crateName, crateConfig));
        }

        // Конец: подводка к финальному призу
        for (int i = 0; i < 6; i++) {
            timeline.add(randomVisualPrize(crateName, crateConfig));
        }

        // Финальный приз должен оказаться по центру
        timeline.add(finalPrize);

        // После финала ещё 2 справа, чтобы updateVisibleItems не вышел за границы
        timeline.add(randomVisualPrize(crateName, crateConfig));
        timeline.add(randomVisualPrize(crateName, crateConfig));

        this.centerIndex = 2;
        this.shiftsDone = 0;
        this.tick = 0;
        this.nextShiftTick = 0;
        this.currentDelay = 1;

        // Останавливаемся, когда центр доедет до finalPrize
        this.totalShifts = timeline.size() - 3 - centerIndex;
    }

    private int calculateDelay(int shiftsDone, int totalShifts) {
        double progress = (double) shiftsDone / (double) totalShifts;

        if (progress < 0.45D) return 1;
        if (progress < 0.70D) return 2;
        if (progress < 0.82D) return 3;
        if (progress < 0.90D) return 4;
        if (progress < 0.96D) return 6;
        return 8;
    }

    private void spawnArmorStands() {
        removeArmorStands();

        Location base = crateBlock.getLocation().clone().add(0.5D, 1.1D, 0.5D);
        World world = base.getWorld();
        if (world == null) {
            return;
        }

        VectorDirection direction = resolveDirection(crateBlock.getLocation());

        // 5 позиций: [-2, -1, 0, 1, 2]
        for (int i = -2; i <= 2; i++) {
            Location loc = base.clone().add(
                    direction.rightX * (i * 0.60D),
                    0.0D,
                    direction.rightZ * (i * 0.60D)
            );

            ArmorStand stand = (ArmorStand) world.spawnEntity(loc, EntityType.ARMOR_STAND);
            prepareStand(stand, i == 0);

            stands.add(stand);
        }
    }

    private void prepareStand(ArmorStand stand, boolean center) {
        stand.setVisible(false);
        stand.setGravity(false);
        stand.setMarker(false);
        stand.setSmall(!center);
        stand.setArms(false);
        stand.setBasePlate(false);
        stand.setInvulnerable(true);
        stand.setSilent(true);
        stand.setCollidable(false);
        stand.setCanPickupItems(false);

        if (center) {
            stand.setHeadPose(new EulerAngle(0.0D, 0.0D, 0.0D));
        } else {
            stand.setHeadPose(new EulerAngle(0.0D, 0.25D, 0.0D));
        }
    }

    private void updateVisibleItems(boolean initial) {
        if (stands.size() != 5) {
            return;
        }

        stands.get(0).getEquipment().setHelmet(clonePrizeItem(timeline.get(centerIndex - 2)));
        stands.get(1).getEquipment().setHelmet(clonePrizeItem(timeline.get(centerIndex - 1)));
        stands.get(2).getEquipment().setHelmet(clonePrizeItem(timeline.get(centerIndex)));
        stands.get(3).getEquipment().setHelmet(clonePrizeItem(timeline.get(centerIndex + 1)));
        stands.get(4).getEquipment().setHelmet(clonePrizeItem(timeline.get(centerIndex + 2)));

        if (initial) {
            highlightCenter();
        }
    }

    private void highlightCenter() {
        if (stands.size() != 5) {
            return;
        }

        for (int i = 0; i < stands.size(); i++) {
            ArmorStand stand = stands.get(i);
            stand.setGlowing(i == 2);
            stand.setCustomNameVisible(false);
        }
    }

    private void spinIdleEffect() {
        if (stands.isEmpty()) {
            return;
        }

        for (int i = 0; i < stands.size(); i++) {
            ArmorStand stand = stands.get(i);
            EulerAngle pose = stand.getHeadPose();
            double y = pose.getY() + (i == 2 ? 0.08D : 0.05D);
            stand.setHeadPose(new EulerAngle(0.0D, y, 0.0D));
        }
    }

    private void playSpinTickSound() {
        World world = crateBlock.getLocation().getWorld();
        if (world == null) {
            return;
        }

        world.playSound(crateBlock.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.7F, 1.8F);
    }

    private void finishOpening() {
        if (finished) {
            return;
        }

        finished = true;

        World world = crateBlock.getLocation().getWorld();
        if (world != null) {
            world.playSound(crateBlock.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
            world.playSound(crateBlock.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.9F, 1.2F);
        }

        spawnFirework();

        // На пару секунд оставляем только центральный предмет
        for (int i = 0; i < stands.size(); i++) {
            if (i != 2 && stands.get(i) != null && !stands.get(i).isDead()) {
                stands.get(i).remove();
            }
        }

        Bukkit.getScheduler().runTaskLater(ACrates.getInstance(), () -> {
            if (!rewardGiven) {
                giveFinalPrize();
            }
        }, 30L);

        Bukkit.getScheduler().runTaskLater(ACrates.getInstance(), () -> {
            removeArmorStands();

            try {
                ACrates.getInstance().getCratesManager().removeOpenCrate(this);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, 60L);
    }

    private void giveFinalPrize() {
        if (rewardGiven || finalPrize == null) {
            return;
        }

        rewardGiven = true;

        String crateName = crateBlock.getCrateName();
        YamlConfiguration crateConfig = ACrates.getInstance().getCratesManager().getCrateConfig(crateName);
        if (crateConfig == null) {
            return;
        }

        try {
            Utils.givePrize(player, crateConfig, "prizes." + finalPrize.getId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void forceStop() {
        finished = true;

        if (task != null) {
            task.cancel();
            task = null;
        }

        removeArmorStands();

        try {
            ACrates.getInstance().getCratesManager().removeOpenCrate(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void removeArmorStands() {
        for (ArmorStand stand : stands) {
            if (stand != null && !stand.isDead()) {
                stand.remove();
            }
        }
        stands.clear();
    }

    private void spawnFirework() {
        World world = crateBlock.getLocation().getWorld();
        if (world == null) {
            return;
        }

        try {
            Firework firework = (Firework) world.spawnEntity(
                    crateBlock.getLocation().clone().add(0.5D, 1.5D, 0.5D),
                    EntityType.FIREWORK_ROCKET
            );

            FireworkMeta meta = firework.getFireworkMeta();
            meta.setPower(0);
            meta.addEffect(
                    FireworkEffect.builder()
                            .withColor(Color.YELLOW, Color.ORANGE)
                            .withFade(Color.WHITE)
                            .flicker(true)
                            .trail(true)
                            .build()
            );
            firework.setFireworkMeta(meta);

            Bukkit.getScheduler().runTaskLater(ACrates.getInstance(), firework::detonate, 2L);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private OpenPrize rollPrize(String crateName, YamlConfiguration crateConfig) {
        ConfigurationSection prizesSection = crateConfig.getConfigurationSection("prizes");
        if (prizesSection == null) {
            throw new IllegalStateException("Prizes section is null for crate " + crateName);
        }

        List<String> ids = new ArrayList<>(prizesSection.getKeys(false));
        int totalWeight = 0;

        for (String id : ids) {
            int weight = Math.max(1, crateConfig.getInt("prizes." + id + ".weight", 1));
            totalWeight += weight;
        }

        int random = ThreadLocalRandom.current().nextInt(totalWeight) + 1;
        int current = 0;

        for (String id : ids) {
            int weight = Math.max(1, crateConfig.getInt("prizes." + id + ".weight", 1));
            current += weight;

            if (current >= random) {
                return createPrize(crateName, crateConfig, id);
            }
        }

        return createPrize(crateName, crateConfig, ids.get(ids.size() - 1));
    }

    private OpenPrize randomVisualPrize(String crateName, YamlConfiguration crateConfig) {
        ConfigurationSection prizesSection = crateConfig.getConfigurationSection("prizes");
        if (prizesSection == null) {
            throw new IllegalStateException("Prizes section is null for crate " + crateName);
        }

        List<String> ids = new ArrayList<>(prizesSection.getKeys(false));
        String randomId = ids.get(ThreadLocalRandom.current().nextInt(ids.size()));

        return createPrize(crateName, crateConfig, randomId);
    }

    private OpenPrize createPrize(String crateName, YamlConfiguration crateConfig, String prizeId) {
        // Если у тебя Utils.getItem(crateConfig, prizeId) уже есть — отлично.
        // Если сигнатура другая, подставь здесь свою.
        ItemStack item = Utils.getItem(crateConfig, prizeId);

        if (item == null || item.getType() == Material.AIR) {
            item = new ItemStack(Material.BARRIER);
        }

        // Если у тебя в OpenPrize другое имя getter'а/constructor — поправь только эту строку
        return new OpenPrize(item, crateName, prizeId);
    }

    private ItemStack clonePrizeItem(OpenPrize prize) {
        if (prize == null || prize.getItem() == null) {
            return new ItemStack(Material.BARRIER);
        }

        return prize.getDisplayItem().clone();
    }

    private VectorDirection resolveDirection(Location location) {
        BlockFace face = getHorizontalFacing(location.getYaw());

        return switch (face) {
            case NORTH -> new VectorDirection(1.0D, 0.0D);
            case SOUTH -> new VectorDirection(-1.0D, 0.0D);
            case EAST -> new VectorDirection(0.0D, 1.0D);
            case WEST -> new VectorDirection(0.0D, -1.0D);
            default -> new VectorDirection(1.0D, 0.0D);
        };
    }

    private BlockFace getHorizontalFacing(float yaw) {
        float normalizedYaw = yaw % 360.0F;
        if (normalizedYaw < 0) {
            normalizedYaw += 360.0F;
        }

        if (normalizedYaw >= 45.0F && normalizedYaw < 135.0F) {
            return BlockFace.WEST;
        }
        if (normalizedYaw >= 135.0F && normalizedYaw < 225.0F) {
            return BlockFace.NORTH;
        }
        if (normalizedYaw >= 225.0F && normalizedYaw < 315.0F) {
            return BlockFace.EAST;
        }
        return BlockFace.SOUTH;
    }

    private static final class VectorDirection {
        private final double rightX;
        private final double rightZ;

        private VectorDirection(double rightX, double rightZ) {
            this.rightX = rightX;
            this.rightZ = rightZ;
        }
    }
}