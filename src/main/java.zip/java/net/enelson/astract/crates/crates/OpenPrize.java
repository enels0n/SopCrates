package net.enelson.astract.crates.crates;

import org.bukkit.inventory.ItemStack;

public class OpenPrize {

	private ItemStack displayItem;
	private String crateName;
	private String id;
	
	OpenPrize(ItemStack displayItem, String crateType, String id) {
		this.displayItem = displayItem;
		this.crateName = crateType;
		this.id = id;
	}
	
	public ItemStack getDisplayItem() {
		return this.displayItem;
	}

	public String getCrateType() {
		return this.crateName;
	}
	
	public String getId() {
		return this.id;
	}
}
