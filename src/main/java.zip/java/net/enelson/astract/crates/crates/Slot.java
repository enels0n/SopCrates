package net.enelson.astract.crates.crates;

import org.bukkit.entity.ArmorStand;

public class Slot {
	
	private ArmorStand armorStand;
	private OpenPrize prize;
	
	Slot(ArmorStand armorStand) {
		this.armorStand = armorStand;
	}
	
	public ArmorStand getArmorStand() {
		return this.armorStand;
	}
	
	public void setPrize(OpenPrize prize) {
		this.prize = prize;
		this.armorStand.getEquipment().setItemInMainHand(prize.getDisplayItem());
	}
	
	public OpenPrize getPrize() {
		return this.prize;
	}
	
	public void remove() {
		this.armorStand.remove();
	}
}
