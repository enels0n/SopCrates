package net.enelson.astract.crates.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

//import com.iridium.iridiumcolorapi.IridiumColorAPI;

import de.tr7zw.nbtapi.NBT;
import de.tr7zw.nbtapi.iface.ReadWriteNBT;
import me.clip.placeholderapi.PlaceholderAPI;
import net.enelson.astract.crates.ACrates;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.md_5.bungee.api.ChatColor;

public class Utils {
	public static Location getDeserializedLocation(String s) {
		final String[] split = s.split(",");
		return new Location(Bukkit.getWorld(split[0]), Double.parseDouble(split[1]), Double.parseDouble(split[2]),
				Double.parseDouble(split[3]));
	}

	public static String getSerializedLocation(Location loc) {
		return loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
	}

	public static String getType(ItemStack item) {
		if (item == null || item.getType().equals(Material.AIR))
			return null;
		String type = NBT.get(item, nbt -> (String) nbt.getString("ACrates"));
		if (type == null || type.equals(""))
			return null;
		return type;
	}

	public static String getCardinalDirection(Entity e) {
		double rotation = (e.getLocation().getYaw() - 90.0F) % 360.0F;

		if (rotation < 0.0D) {
			rotation += 360.0D;
		}
		if ((0.0D <= rotation) && (rotation < 45.0D))
			return "W";
		if ((45.0D <= rotation) && (rotation < 135.0D))
			return "N";
		if ((135.0D <= rotation) && (rotation < 225.0D))
			return "E";
		if ((225.0D <= rotation) && (rotation < 315.0D))
			return "S";
		if ((315.0D <= rotation) && (rotation < 360.0D)) {
			return "W";
		}
		return null;
	}

	public static void runCommands(List<String> commands, Player player) {
		for (String command : commands) {
			if (command.startsWith("[message] ")) {
				String message = PlaceholderAPI.setPlaceholders(player, command.replaceFirst("\\[message\\] ", ""));
				player.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
				//player.sendMessage(IridiumColorAPI.process(message));
			} else if (command.startsWith("[minimessage] ")) {
				if(ACrates.getInstance().getAdventure() == null) {
					System.out.println("Попытка использовать [minimessage] при отсутствующих зависимостях.");
					System.out.println("(" + command + ")");
					continue;
				}
				String message = PlaceholderAPI.setPlaceholders(player, command.replaceFirst("\\[minimessage\\] ", ""));
				ACrates.getInstance().getAdventure().player(player).sendMessage(MiniMessage.miniMessage().deserialize(message));
			} else if (command.startsWith("[console] ")) {
				Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
						PlaceholderAPI.setPlaceholders(player, command.replaceFirst("\\[console\\] ", "")));
			} else if (command.startsWith("[player] ")) {
				Bukkit.dispatchCommand(player,
						PlaceholderAPI.setPlaceholders(player, command.replaceFirst("\\[player\\] ", "")));
			} else if (command.startsWith("[broadcast] ")) {
				String message = PlaceholderAPI.setPlaceholders(player, command.replaceFirst("\\[broadcast\\] ", ""));
				for (Player p : Bukkit.getOnlinePlayers()) {
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
					//p.sendMessage(IridiumColorAPI.process(message));
				}
			} else if (command.startsWith("[broadcastworld] ")) {
				String message = PlaceholderAPI.setPlaceholders(player,
						command.replaceFirst("\\[broadcastworld\\] ", ""));
				for (Player p : Bukkit.getOnlinePlayers()) {
					if (p.getWorld().equals(player.getWorld()))
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
						//p.sendMessage(IridiumColorAPI.process(message));
				}
			} else if (command.startsWith("[broadcastnear] ")) {
				String message = PlaceholderAPI.setPlaceholders(player,
						command.replaceFirst("\\[broadcastnear\\] ", ""));
				for (Player p : Bukkit.getOnlinePlayers()) {
					if (player.getLocation().distance(p.getLocation()) <= 10)
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
					//p.sendMessage(IridiumColorAPI.process(message));
				}
			}
		}
	}

	public static ItemStack getHead(String value, String name) {
		ItemStack head = new ItemStack(Material.PLAYER_HEAD);
		/**
		 * NBTItem nbti = new NBTItem(head); NBTCompound disp =
		 * nbti.addCompound("display");
		 * 
		 * if(name != null) disp.setString("Name", IridiumColorAPI.process(name));
		 * 
		 * String uuid = new UUID(value.hashCode(), value.hashCode()).toString();
		 * 
		 * NBTCompound skull = nbti.addCompound(name); skull.setString("Name", "tr7zw");
		 * skull.setString("Id", uuid); NBTListCompound texture =
		 * skull.addCompound("Properties").getCompoundList("textures").addCompound();
		 * texture.setString("Signature",
		 * "XpRfRz6/vXE6ip7/vq+40H6W70GFB0yjG6k8hG4pmFdnJFR+VQhslE0gXX/i0OAGThcAVSIT+/W1685wUxNofAiy+EhcxGNxNSJkYfOgXEVHTCuugpr+EQCUBI6muHDKms3PqY8ECxdbFTUEuWxdeiJsGt9VjHZMmUukkGhk0IobjQS3hjQ44FiT1tXuUU86oAxqjlKFpXG/iXtpcoXa33IObSI1S3gCKzVPOkMGlHZqRqKKElB54I2Qo4g5CJ+noudIDTzxPFwEEM6XrbM0YBi+SOdRvTbmrlkWF+ndzVWEINoEf++2hkO0gfeCqFqSMHuklMSgeNr/YtFZC5ShJRRv7zbyNF33jZ5DYNVR+KAK9iLO6prZhCVUkZxb1/BjOze6aN7kyN01u3nurKX6n3yQsoQQ0anDW6gNLKzO/mCvoCEvgecjaOQarktl/xYtD4YvdTTlnAlv2bfcXUtc++3UPIUbzf/jpf2g2wf6BGomzFteyPDu4USjBdpeWMBz9PxVzlVpDAtBYClFH/PFEQHMDtL5Q+VxUPu52XlzlUreMHpLT9EL92xwCAwVBBhrarQQWuLjAQXkp3oBdw6hlX6Fj0AafMJuGkFrYzcD7nNr61l9ErZmTWnqTxkJWZfZxmYBsFgV35SKc8rkRSHBNjcdKJZVN4GA+ZQH5B55mi4=");
		 * texture.setString("Value", value);
		 * 
		 * NBTCompoundList attribute = nbti.getCompoundList("AttributeModifiers");
		 * NBTListCompound mod1 = attribute.addCompound(); mod1.setInteger("Amount",
		 * 10); mod1.setString("AttributeName", "generic.maxHealth");
		 * mod1.setString("Name", "generic.maxHealth"); mod1.setInteger("Operation", 0);
		 * mod1.setInteger("UUIDLeast", 59664); mod1.setInteger("UUIDMost", 31453);
		 * 
		 * nbti.setInteger("HideFlags", 4); nbti.setBoolean("Unbreakable", true); head =
		 * nbti.getItem();
		 * 
		 * return head;
		 **/

		NBT.modifyComponents(head, nbt -> {
			ReadWriteNBT profileNbt = nbt.getOrCreateCompound("minecraft:profile");
			profileNbt.setUUID("id", UUID.fromString("4fbecd49-c7d4-4c18-8410-adf7a7348728"));
			ReadWriteNBT propertiesNbt = profileNbt.getCompoundList("properties").addCompound();
			propertiesNbt.setString("name", "textures");
			propertiesNbt.setString("value", value);
		});

		return head;

		/**
		 * ItemStack head = new
		 * ItemStack(Material.PLAYER_HEAD); @SuppressWarnings("deprecation") ItemStack
		 * item = Bukkit.getUnsafe().modifyItemStack(head, "{SkullOwner:{Name:\"" + name
		 * + "\",Id:" + uuid + ",Properties:{textures:[{Value:\"" + value + "\"}]}}}");
		 * ItemMeta meta = item.getItemMeta(); if(name != null)
		 * meta.setDisplayName(IridiumColorAPI.process(name)); item.setItemMeta(meta);
		 * 
		 * return item;
		 **/
	}


	public static ItemStack getHeadURL(String url, String name) {
		ItemStack item = new ItemStack(Material.PLAYER_HEAD);
		NBT.modify(item, nbt -> {
		    ReadWriteNBT skullOwnerCompound = nbt.getOrCreateCompound("SkullOwner");

		    // The owner UUID. Note that skulls with the same UUID but different textures will misbehave and only one texture will load.
		    // They will share the texture. To avoid this limitation, it is recommended to use a random UUID.
		    skullOwnerCompound.setUUID("Id", UUID.randomUUID());

		    skullOwnerCompound.getOrCreateCompound("Properties")
		        .getCompoundList("textures")
		        .addCompound()
		        .setString("Value", url);
		});
		return item;
	}
	
//	@SuppressWarnings("deprecation") // 1.21.1
//	public static ItemStack getHeadURL(String url, String name) {
//		ItemStack item = new ItemStack(Material.PLAYER_HEAD);
//		ItemMeta meta = item.getItemMeta();
//		SkullMeta skullMeta = (SkullMeta) meta;
//		PlayerProfile pp = Bukkit.createPlayerProfile(UUID.fromString("4fbecd49-c7d4-4c18-8410-adf7a7348728"));
//		PlayerTextures pt = pp.getTextures();
//		try {
//			pt.setSkin(new URL("http://textures.minecraft.net/texture/" + url));
//		} catch (MalformedURLException e) {
//			e.printStackTrace();
//		}
//		skullMeta.setOwnerProfile(pp);
//		meta = skullMeta;
//		item.setItemMeta(meta);
//		return item;
//	}

	public static List<String> translateColorList(List<String> list) {
		List<String> newList = new ArrayList<String>();
		for (String l : list) {
			//newList.add(IridiumColorAPI.process(l));
			newList.add(ChatColor.translateAlternateColorCodes('&', l));
		}
		return newList;
	}

	public static ItemStack setTags(ItemStack item, List<String> tags) {
		NBT.modify(item, nbt -> {
			for (String t : tags) {
				nbt.setString(t.split("::")[0], t.split("::")[1]);
			}
		});
		return item;
	}

	@SuppressWarnings("unchecked")
	public static ItemStack getItem(Map<?, ?> itemMap) {
		if (itemMap.get("material") == null)
			return new ItemStack(Material.AIR);

		String material = (String) itemMap.get("material");
		int amount = itemMap.get("amount") == null ? 1 : (int) itemMap.get("amount");
		String name = itemMap.get("name") == null ? null : (String) itemMap.get("name");
		List<String> lore = itemMap.get("lore") == null ? null : (List<String>) itemMap.get("lore");
		List<String> enchantments = itemMap.get("enchantments") == null ? null
				: (List<String>) itemMap.get("enchantments");
		boolean hideEnchantments = itemMap.get("hideEnchantments") == null ? false
				: (boolean) itemMap.get("hideEnchantments");
		List<String> nbts = (List<String>) itemMap.get("nbts") == null ? null : (List<String>) itemMap.get("nbts");
		int model = itemMap.get("model") == null ? 0 : (int) itemMap.get("model");
		return getItem(material, amount, name, lore, enchantments, hideEnchantments, nbts, model, false, "prize", "0");
	}

	public static ItemStack getItem(YamlConfiguration crateConfig, String id) {
		String material = crateConfig.getString("prizes." + id + ".display.material");
		int amount = crateConfig.getInt("prizes." + id + ".display.amount");
		String name = crateConfig.getString("prizes." + id + ".display.name");
		List<String> lore = crateConfig.getStringList("prizes." + id + ".display.lore");
		List<String> enchantments = crateConfig.getStringList("prizes." + id + ".display.enchantments");
		boolean hideEnchantments = crateConfig.getBoolean("prizes." + id + ".display.hideEnchantments");
		int model = crateConfig.getInt("prizes." + id + ".display.model");
		boolean glowing = crateConfig.getBoolean("prizes." + id + ".display.glowing");
		return getItem(material, amount, name, lore, enchantments, hideEnchantments, null, model, glowing, "display",
				id);
	}

	public static ItemStack getItem(String material, int amount, String name, List<String> lore,
			List<String> enchantments, boolean hideEnchantments, List<String> nbts, int model, boolean glowing,
			String type, String id) {
		ItemStack item;
		if (material.startsWith("PLAYER_HEAD:")) {
			String value = material.replaceFirst("PLAYER_HEAD:", "");
			item = Utils.getHead(value, "Prize");
		} else if (material.startsWith("PLAYER_HEAD_URL:")) {
			String value = material.replaceFirst("PLAYER_HEAD_URL:", "");
			item = Utils.getHeadURL(value, "Prize");
		} else {
			item = new ItemStack(Material.valueOf(material));
		}

		if (type.equals("display") && glowing && (enchantments == null || enchantments.isEmpty())) {
			item.addUnsafeEnchantment(Enchantment.MENDING, 1);
			ItemMeta meta = item.getItemMeta();
			meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
			item.setItemMeta(meta);
		}

		if (enchantments != null) {
			for (String enchantment : enchantments) {
				item.addUnsafeEnchantment(
						Registry.ENCHANTMENT.get(NamespacedKey.minecraft(enchantment.split(":")[0].toLowerCase())),
						Integer.parseInt(enchantment.split(":")[1]));
			}
			if (hideEnchantments) {
				ItemMeta meta = item.getItemMeta();
				meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
				item.setItemMeta(meta);
			}
		}

		if (type.equals("display")) {
			NBT.modify(item, nbt -> {
				nbt.setString("ACrates-prizeId", id);
			});
		}

		if (type.equals("prize") && nbts != null) {
			NBT.modify(item, nbt -> {
				for (String n : nbts) {
					nbt.setString(n.split("::")[0], n.split("::")[1]);
				}
			});
		}

		ItemMeta meta = item.getItemMeta();
		if (model > 0)
			meta.setCustomModelData(model);

		if (name != null)
			meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
			//meta.setDisplayName(IridiumColorAPI.process(name));

		if (lore != null)
			meta.setLore(coloringStringList(lore));

		item.setItemMeta(meta);
		item.setAmount(amount == 0 ? 1 : amount);

		return item;
	}

	public static List<String> coloringStringList(List<String> list) {
		List<String> newList = new ArrayList<>();
		for (String line : list) {
			newList.add(coloring(line));
			//newList.add(IridiumColorAPI.process(line));
		}
		return newList;
	}

	public static void pushPlayer(Player player) {
		Vector direction = player.getLocation().getDirection().normalize();
		Vector right = direction.clone().crossProduct(new Vector(0, 1, 0)).normalize();
		Vector pushDirection = direction.multiply(-0.5).add(right.multiply(0.15));
		player.setVelocity(pushDirection);
	}

	@SuppressWarnings("unchecked")
	public static void givePrize(Player player, YamlConfiguration crateConfig, String prizeLink) {
		if (crateConfig.get(prizeLink + ".checkAlternatives") != null) {
			List<Map<?, ?>> permissionsList = crateConfig.getMapList(prizeLink + ".checkAlternatives");

			checkPremissions:
			for (Map<?, ?> permissionMap : permissionsList) {
				boolean checkPermission = false;
				String type = (String) permissionMap.get("type");
				
				List<Map<?, ?>> checks = (List<Map<?, ?>>) permissionMap.get("checks");
				for (Map<?, ?> check : checks) {
					boolean equals = checkInput(player, check);
					if (type.equals("all")) {
						if (equals)
							continue;
						continue checkPremissions;
					}

					if (type.equals("any")) {
						if (equals) {
							checkPermission = true;
							break;
						}
						continue;
					}
				}

				if (type.equals("any") && !checkPermission)
					continue;

				// Выполняем альтернативные действия
				if (permissionMap.containsKey("alternative")) {
					Map<?, ?> alternative = (Map<?, ?>) permissionMap.get("alternative");
					if (alternative.get("commands") != null) {
						List<String> commands = (List<String>) alternative.get("commands");
						Utils.runCommands(commands, player);
					}
					if (alternative.get("items") != null) {
						List<Map<?, ?>> itemDetails = (List<Map<?, ?>>) alternative.get("items");
						for (Map<?, ?> itemDetail : itemDetails) {
							ItemStack item = Utils.getItem(itemDetail);
							if (player.getInventory().addItem(item).size() != 0) {
								player.getWorld().dropItem(player.getLocation(), item);
							}
						}
					}
				}
				return;
			}
		}

		// Выполнение команд и выдача предметов, если пройденные проверки не выдали приз
		if (crateConfig.get(prizeLink + ".prize.commands") != null) {
			Utils.runCommands(crateConfig.getStringList(prizeLink + ".prize.commands"), player);
		}
		if (crateConfig.get(prizeLink + ".prize.items") != null) {
			for (Map<?, ?> itemMap : crateConfig.getMapList(prizeLink + ".prize.items")) {
				ItemStack item = Utils.getItem(itemMap);
				if (player.getInventory().addItem(item).size() != 0) {
					player.getWorld().dropItem(player.getLocation(), item);
				}
			}
		}
	}
//	public static void givePrize(Player player, YamlConfiguration crateConfig, String prizeLink) {
//		if (crateConfig.getBoolean(prizeLink + ".checkPermission.enable")) {
//			boolean any = crateConfig.getString(prizeLink + ".checkPermission.type").equals("any");
//			for (String perm : crateConfig.getStringList(prizeLink + ".checkPermission.permissions")) {
//				if (any && !player.isPermissionSet(perm)) {
//					continue;
//				}
//
//				if (!any && !player.isPermissionSet(perm)) {
//					break;
//				}
//				prizeLink += ".checkPermission.alternative";
//				break;
//			}
//		}
//		
//		if(crateConfig.get(prizeLink+".prize.commands") != null) {
//			Utils.runCommands(crateConfig.getStringList(prizeLink+".prize.commands"), player);
//		}
//		if(crateConfig.get(prizeLink+".prize.items") != null) {
//			for(Map<?, ?> itemMap : crateConfig.getMapList(prizeLink + ".prize.items")) {
//				ItemStack item = Utils.getItem(itemMap);
//				if (player.getInventory().addItem(item).size() != 0) {
//					player.getWorld().dropItem(player.getLocation(), item);
//				}
//			}
//		}
//	}
	
	public static boolean checkInput(Player player, Map<?, ?> check) {
		CheckType type = CheckType.getType((String)check.get("type"));
		String input = (String)check.get("input");
		String output = check.get("output") != null ? (String)check.get("output") : null;
		
		switch (type) {
			case HAS_PERM:
				return player.isPermissionSet(input);
			case HAS_NO_PERM:
				return !player.isPermissionSet(input);
			case STRING_EQUALS:
				return PlaceholderAPI.setPlaceholders(player, input).equalsIgnoreCase(PlaceholderAPI.setPlaceholders(player, output));
			case STRING_NOT_EQUALS:
				return !PlaceholderAPI.setPlaceholders(player, input).equalsIgnoreCase(PlaceholderAPI.setPlaceholders(player, output));
		}
		return false;
	}
	
	public static String coloring(String string) {
		return PlaceholderAPI.setPlaceholders(null, "%acolor_"+string+"%");
	}
}
